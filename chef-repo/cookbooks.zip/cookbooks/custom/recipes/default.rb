#
# Cookbook:: custom
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved.
#
#
custom_site 'httpd' do
  homepage '<h1>Welcome to the Example Co. website!</h1>'
end
