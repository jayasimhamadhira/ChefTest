#
# Cookbook:: customresource
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved.
#
customresource_site 'httpd' do
  homepage '<h1>Welcome to the Example Co. website!</h1>'
end

