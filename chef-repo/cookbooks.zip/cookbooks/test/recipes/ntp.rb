package 'Install NTP' do
   package_name 'ntp'
   action :install    
end 
#service "ntp" do
#   action [ :enable, :start ]
#end
